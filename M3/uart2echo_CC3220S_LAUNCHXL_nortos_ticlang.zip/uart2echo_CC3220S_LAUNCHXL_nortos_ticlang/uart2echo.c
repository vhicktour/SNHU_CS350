/*
 * Copyright (c) 2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uart2echo.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>  // For string comparison

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Define states for the state machine */
typedef enum {
    WAIT_FOR_ON,
    WAIT_FOR_OFF
} LEDState;

LEDState ledState = WAIT_FOR_ON;  // Initial state

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char inputBuffer[4] = {0};  // Buffer to hold incoming characters ("ON" or "OFF")
    int bufferIndex = 0;
    const char echoPrompt[] = "Type 'ON' to turn on LED, 'OFF' to turn it off.\r\n";
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t bytesRead;
    size_t bytesWritten = 0;
    uint32_t status     = UART2_STATUS_SUCCESS;

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);  // Initialize LED to OFF

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL)
    {
        /* UART2_open() failed */
        while (1) {}
    }

    /* Send initial prompt */
    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    /* Loop forever to handle input and LED control */
    while (1)
    {
        /* Read a character from the UART */
        bytesRead = 0;
        status = UART2_read(uart, &inputBuffer[bufferIndex], 1, &bytesRead);

        if (status == UART2_STATUS_SUCCESS && bytesRead > 0)
        {
            UART2_write(uart, &inputBuffer[bufferIndex], 1, &bytesWritten);  // Echo the input back
            bufferIndex++;

            // Process input once we have received at least 2 characters (for "ON") or 3 characters (for "OFF")
            if ((bufferIndex == 2 && strncmp(inputBuffer, "ON", 2) == 0) ||
                (bufferIndex == 3 && strncmp(inputBuffer, "OFF", 3) == 0))
            {
                // Handle the state transition based on input
                if (strncmp(inputBuffer, "ON", 2) == 0)
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);  // Turn the LED ON
                    UART2_write(uart, "LED is ON\r\n", 11, &bytesWritten);
                    ledState = WAIT_FOR_OFF;
                }
                else if (strncmp(inputBuffer, "OFF", 3) == 0)
                {
                    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);  // Turn the LED OFF
                    UART2_write(uart, "LED is OFF\r\n", 12, &bytesWritten);
                    ledState = WAIT_FOR_ON;
                }

                // Reset buffer after processing the command
                memset(inputBuffer, 0, sizeof(inputBuffer));
                bufferIndex = 0;
            }
            else if (bufferIndex >= 3)
            {
                // If the input buffer exceeds "OFF", reset it
                memset(inputBuffer, 0, sizeof(inputBuffer));
                bufferIndex = 0;
            }
        }
    }
}
